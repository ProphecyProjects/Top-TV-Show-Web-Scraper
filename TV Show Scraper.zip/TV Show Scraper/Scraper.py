import csv
import requests
from bs4 import BeautifulSoup

url = "https://www.imdb.com/chart/toptv/"

# make a request to the IMDb top TV shows page
response = requests.get(url)

# parse the HTML content using BeautifulSoup
soup = BeautifulSoup(response.content, 'html.parser')

# find the list of TV shows in the HTML
tv_show_list = soup.find('tbody', {'class': 'lister-list'})

# Write the list of TV shows to a CSV file
with open('tv_shows.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['Title', 'Year', 'Rating'])
    for tv_show in tv_show_list.find_all('tr'):
        year = tv_show.find('span', class_='secondaryInfo').text.strip('()')
        title = tv_show.find('td', {'class': 'titleColumn'}).a.text
        rating = tv_show.find('td', {'class': 'ratingColumn'}).strong.text
        writer.writerow([title, year,  rating])
        print(f'{title} - ({year}) - {rating}')

# loop through each TV show and print its title and rating
for tv_show in tv_show_list.find_all('tr'):
    year = tv_show.find('span', class_='secondaryInfo').text.strip('()')
    title = tv_show.find('td', {'class': 'titleColumn'}).a.text
    rating = tv_show.find('td', {'class': 'ratingColumn'}).strong.text
    print(f'{title} - ({year}) - {rating}')
